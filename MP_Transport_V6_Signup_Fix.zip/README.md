MP Transport V6 — Signup button fix

Fixed email sign-up and login controls not responding after opening the authentication view: binds action handlers after drawing the form. Supabase Auth still needs email confirmation enabled and approved redirect URL. No database migration needed.

Render build command:
mkdir -p public && python3 -m zipfile -e MP_Transport_V6_Signup_Fix.zip public
