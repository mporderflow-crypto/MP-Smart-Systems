# MP Transport - Render Static Site

Upload `index.html` to the ROOT of your private GitHub repository `mp-transport`.

Render settings:
- Service Type: Static Site
- Name: mp-transport
- Branch: main
- Root Directory: leave blank
- Build Command: `mkdir -p public && cp index.html public/index.html`
- Publish Directory: `public`

This prototype uses an existing Supabase backend. It is not production-ready: first admin must be provisioned securely, and auth/RLS workflows must be tested before onboarding users.
