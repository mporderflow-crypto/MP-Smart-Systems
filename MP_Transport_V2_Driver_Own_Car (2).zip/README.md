# MP Transport - คนขับใช้รถส่วนตัว

อัปโหลด ZIP ทั้งไฟล์ไปที่ GitHub repository เดิม แล้วแก้ Build Command ใน Render ให้เป็น:

```
mkdir -p public && python3 -m zipfile -e MP_Transport_Own_Vehicle_Render.zip public
```

Publish Directory: `public`

ฐานข้อมูล Supabase ถูกเพิ่มช่องการสมัครคนขับรถส่วนตัวแล้ว และบัญชีต้องผ่านการอนุมัติก่อนรับงาน
