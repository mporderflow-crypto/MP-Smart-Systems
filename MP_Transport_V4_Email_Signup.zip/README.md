# MP Transport V4 — Email signup & Host

* สมัครคนขับใช้รถตัวเองหรือร้านค้าด้วยอีเมล/รหัสผ่าน
* ยืนยันอีเมลผ่าน Supabase Auth (ต้องเปิด Confirm Email ใน Supabase)
* ส่งอีเมลยืนยันซ้ำและลืมรหัสผ่าน
* ทางเข้าโฮสต์ยังแยกที่ `/?host=1` และไม่มีเมนูสมัครโฮสต์เอง
* โฮสต์ต้องเป็นบัญชี `admin` ที่อนุมัติในฐานข้อมูล จึงเข้าหน้าโฮสต์ได้

## Render static site
อัปโหลด ZIP โดยไม่ต้องแตกไฟล์ แล้วใช้ Build Command ที่ตรงกับชื่อไฟล์ใน GitHub:

`mkdir -p public && python3 -m zipfile -e MP_Transport_V4_Email_Signup.zip public`

Publish Directory: `public`

## Supabase Settings (สำคัญ)
Auth → URL Configuration: Site URL และ Redirect URL = `https://mp-smart-systems.onrender.com/`
Auth → Providers → Email: เปิด Confirm Email (โปรดตรวจผลกระทบเพราะ Supabase โปรเจกต์นี้ใช้ร่วมกับ MP OrderFlow)
ตั้งค่า SMTP สำหรับผู้ใช้งานจำนวนมาก และตรวจส่งอีเมลจริงก่อนเปิดระบบ
ไม่ต้องเพิ่ม `service_role` key ในเว็บไซต์
